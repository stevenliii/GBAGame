/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 gamewonbackground gamewonbackground.png 
 * Time-stamp: Tuesday 04/02/2024, 07:24:24
 * 
 * Image Information
 * -----------------
 * gamewonbackground.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMEWONBACKGROUND_H
#define GAMEWONBACKGROUND_H

extern const unsigned short gamewonbackground[38400];
#define GAMEWONBACKGROUND_SIZE 76800
#define GAMEWONBACKGROUND_LENGTH 38400
#define GAMEWONBACKGROUND_WIDTH 240
#define GAMEWONBACKGROUND_HEIGHT 160

#endif

