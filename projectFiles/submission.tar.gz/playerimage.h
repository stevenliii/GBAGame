/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=10x10 playerimage playerimage.png 
 * Time-stamp: Tuesday 04/02/2024, 08:29:39
 * 
 * Image Information
 * -----------------
 * playerimage.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYERIMAGE_H
#define PLAYERIMAGE_H

extern const unsigned short playerimage[100];
#define PLAYERIMAGE_SIZE 200
#define PLAYERIMAGE_LENGTH 100
#define PLAYERIMAGE_WIDTH 10
#define PLAYERIMAGE_HEIGHT 10

#endif

