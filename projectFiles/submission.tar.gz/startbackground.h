/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 startbackground startbackground.png 
 * Time-stamp: Tuesday 04/02/2024, 07:28:31
 * 
 * Image Information
 * -----------------
 * startbackground.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTBACKGROUND_H
#define STARTBACKGROUND_H

extern const unsigned short startbackground[38400];
#define STARTBACKGROUND_SIZE 76800
#define STARTBACKGROUND_LENGTH 38400
#define STARTBACKGROUND_WIDTH 240
#define STARTBACKGROUND_HEIGHT 160

#endif

